#ifndef _PID_H_
#define _PID_H_

#define  MIDSTRING 3300       //�����ֵ
#define  errss 1.2        //���ϵ��
struct STEER_PID
{
    float fKp; // ��������΢��
    float fKi;
    float fKd;
};
extern struct STEER_PID  SD_PID;
extern struct STEER_PID  SD5_PID;
extern   float err;


extern void SteerPwmInit();
extern void STEER_PID_init(struct STEER_PID *SD_PID,float Kp,float Ki,float Kd);
extern void steerPIDA(struct STEER_PID *SD_PID,unsigned char ROW); //ǰ��PID

#endif