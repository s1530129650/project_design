#define   V                 10
#define   H                 400
#define   linecenter        H/2


#define threshold     128


extern int CCD_V,CCD_H;
extern int LeftBorder[V],RightBorder[V],CenterLine[V];
extern unsigned char ADdata[V][H],Bina_data[V][H];
extern long count,WhiteNum;


extern void camera_send();
extern void BinaData();
extern void AllFilt();
extern void bina_send();
extern void get_center();
extern void thread();