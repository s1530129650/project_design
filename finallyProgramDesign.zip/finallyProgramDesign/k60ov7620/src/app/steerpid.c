#include "camera.h"
#include "FTM.h"
#include "common.h"
#include "gpio.h"
#include "steerPID.h"


extern uint16 ATurnPWM;
struct STEER_PID  SD_PID;
struct STEER_PID  SD5_PID;

float err;
float result;

//���PWM��ʼ��
void SteerPwmInit()
{
  FTM_PWM_init(FTM1, CH1, 100, 15);   //���PWM��ʼ��  145  180 
}

void STEER_PID_init(struct STEER_PID *SD_PID,float Kp,float Ki,float Kd)
{
  SD_PID->fKp = Kp;
  SD_PID->fKi = Ki;
  SD_PID->fKd = Kd;
}

//PID����
void steerPIDA(struct STEER_PID *SD_PID,unsigned char ROW)
{
  float pterm, dterm; 
  static float olderr=0,iterm = 0;	//������
  float pgain,igain,dgain;

  float CCCline=linecenter;


  //����������  
  err =0 ;
  for(CCD_V=ROW;CCD_V<ROW+5;CCD_V++)   err = err + (CCCline - CenterLine[CCD_V]); 
   err = err/5;

  
  
  pgain = SD_PID->fKp;
  igain = SD_PID->fKi;
  dgain = SD_PID->fKd;
    
  pterm = pgain * err;	//P��
  iterm += igain * err; 
  dterm = ((err - olderr)) * dgain; 
    
  /*if(fabsf(err) < 10)	{dterm = 0;pterm=0;iterm = 145;}*/
//  if((fabsf(CenterLine[top_line] - CenterLine[top_line/2]) < 4) && (top_line >=45))	
//    {dterm = 0;iterm=145;}
  
  result = -pterm - dterm; 

  if(result>=1000)
    result=1000;
  if(result<=-1000)
    result=-1000;
    
	
  olderr = err;
  //oldolderr = olderr;
  ATurnPWM=MIDSTRING-result;
  FTM_CnV_REG(FTMx[FTM1], CH1) = ATurnPWM; 
  

}