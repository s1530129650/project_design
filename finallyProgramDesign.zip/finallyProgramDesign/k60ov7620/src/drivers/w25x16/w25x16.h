#ifndef _W25X16_H_
#define _W25X16_H_

void w25x16_init();
u32  w25x16_ReadDeviceID();
u32  w25x16_ReadFlashID(void);




#endif //_W25X16_H_