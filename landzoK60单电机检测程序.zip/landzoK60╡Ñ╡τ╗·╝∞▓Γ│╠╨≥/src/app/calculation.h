


#ifndef  calculation_H
#define  calculation_H  


void LCD_KEY_init (void) ;



void KYELCD(void) ;
void LCDTIME(void) ;

/*********************************************************************************************************
* Description: define
*********************************************************************************************************
*/




#endif
